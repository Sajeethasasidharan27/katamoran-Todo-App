import React from 'react';
import API from '../services/api';

export default function TaskCard({ task, onUpdate }) {
  const toggleComplete = async () => {
    await API.put(`/tasks/${task._id}`, { completed: !task.completed });
    onUpdate();
  };

  return (
    <div>
      <p style={{ textDecoration: task.completed ? 'line-through' : 'none' }}>
        {task.title}
      </p>
      <button onClick={toggleComplete}>
        {task.completed ? 'Undo' : 'Complete'}
      </button>
    </div>
  );
}
