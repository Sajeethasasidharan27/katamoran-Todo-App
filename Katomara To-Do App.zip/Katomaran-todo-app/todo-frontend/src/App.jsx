import React, { useEffect, useState } from 'react';
import TaskCard from './components/TaskCard';
import TaskForm from './pages/TaskForm';
import API from './services/api';

export default function App() {
  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    const res = await API.get('/tasks');
    setTasks(res.data);
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <div>
      <h2>Todo List</h2>
      <TaskForm onAdd={fetchTasks} />
      {tasks.map((task) => (
        <TaskCard key={task._id} task={task} onUpdate={fetchTasks} />
      ))}
    </div>
  );
}
